package com.sukanya.ood1;

public class Bus extends Vehicle{

}
