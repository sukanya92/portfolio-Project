package com.sukanya.ood3;

public class Bus extends Vehicle{

}
