package com.sukanya.common;

import java.time.LocalDate;

public class Validator {
	
	public static boolean validateProps(Integer year,String make,String model) {
		int currYear = LocalDate.now().getYear();
		 
		 if(year==null || year<1970 || year>currYear)
			 return false;
		 
		 if(make==null || make.length()==0)
			 return false;
		 else if (make.length()>0){
			 try {
				Double.parseDouble(make);
				return false;
			} catch (NumberFormatException e) {}
		 }
		 
		 if(model==null || model.length()==0)
			 return false;
		 else if (model.length()>0){
			 try {
				Double.parseDouble(model);
				return false;
			} catch (NumberFormatException e) {}
		 }
		 return true;
	}
	
	
	public static boolean validateProps(Integer year,String make,String model, String type) {
		
		int currYear = LocalDate.now().getYear();
		
		 if(year==null || year<1970 || year>currYear)
			 return false;
		
		 if(make==null || make.length()==0)
			 return false;
		 else if (make.length()>0){
			 try {
				Double.parseDouble(make);
				return false;
			} catch (NumberFormatException e) {}
		 }
		
		 if(model==null || model.length()==0)
			 return false;
		 else if (model.length()>0){
			 try {
				Double.parseDouble(model);
				return false;
			} catch (NumberFormatException e) {}
		 }
		
		 if(type==null || type.length()==0)
			 return false;
		 else if (type.length()>0){
			 try {
				Double.parseDouble(type);
				return false;
			} catch (NumberFormatException e) {}
		 }
		 
		 return true;
	}
}
