package com.sukanya.ood3;

public class MotorCycle extends Vehicle {

}
