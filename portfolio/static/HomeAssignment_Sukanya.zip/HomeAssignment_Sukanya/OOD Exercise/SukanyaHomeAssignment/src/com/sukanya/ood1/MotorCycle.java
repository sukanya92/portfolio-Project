package com.sukanya.ood1;

public class MotorCycle extends Vehicle {

}
