package com.sukanya.ood3;

import javax.xml.bind.annotation.XmlElement;

import com.sukanya.common.Validator3;


public class Vehicle {

	private Integer year;
	private String make;
	private String model;
	private String vin;
	private String license;

	@XmlElement(name="LicensePlateNumber")	
	public String getLicense() {
		return license;
	}
	public void setLicense(String license) {
		this.license = license;
	}
	@XmlElement(name="Year")
	public Integer getYear() {
		return year;
	}
	public void setYear(Integer year) {
		this.year = year;
	}
	@XmlElement(name="Make")
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	@XmlElement(name="Model")
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	
	@XmlElement(name="VinNumber")
	public String getVin() {
		return vin;
	}
	public void setVin(String vin) {
		this.vin = vin;
	}
	
	public boolean validateProps() {
		return Validator3.validateProps(year,make,model,vin, license);
	}

}
