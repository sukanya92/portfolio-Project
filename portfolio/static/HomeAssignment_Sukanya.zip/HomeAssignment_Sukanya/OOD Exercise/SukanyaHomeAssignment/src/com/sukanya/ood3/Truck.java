package com.sukanya.ood3;

public class Truck extends Vehicle{

}
