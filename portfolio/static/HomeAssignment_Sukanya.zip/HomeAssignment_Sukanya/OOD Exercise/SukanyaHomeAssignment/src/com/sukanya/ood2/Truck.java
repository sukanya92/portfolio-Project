package com.sukanya.ood2;

public class Truck extends Vehicle{

}
