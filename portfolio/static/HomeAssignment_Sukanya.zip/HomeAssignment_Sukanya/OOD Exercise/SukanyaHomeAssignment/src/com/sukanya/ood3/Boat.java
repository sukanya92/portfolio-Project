package com.sukanya.ood3;

import javax.xml.bind.annotation.XmlElement;
import com.sukanya.common.Validator3;

public class Boat extends Vehicle{

	private String type;
	private String nrn;

	@XmlElement(name="NauticalRegistrationNumber")
	public String getNrn() {
		return nrn;
	}
	public void setNrn(String nrn) {
		this.nrn = nrn;
	}
	@XmlElement(name="Type")
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public boolean validateProps() {
		return Validator3.validateProps(this.getYear(),this.getMake(),this.getModel(),this.getVin(), nrn, type);
	}
}
