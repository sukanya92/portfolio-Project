package com.sukanya.main;

import java.io.File;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import com.sukanya.ood3.Boat;
import com.sukanya.ood3.Bus;
import com.sukanya.ood3.Fleet;
import com.sukanya.ood3.MotorCycle;
import com.sukanya.ood3.Truck;
import com.sukanya.ood3.Vehicles;

public class Test3 {

	public static void main(String[] args) {
		File file=new File("Fleet3.xml");
		try {
			JAXBContext jaxbCntxt=JAXBContext.newInstance(Fleet.class);
			Unmarshaller jaxbUnm=jaxbCntxt.createUnmarshaller();
			Fleet fleet=(Fleet)jaxbUnm.unmarshal(file);
			Vehicles vehicles=fleet.getVehicles();
			String isValid = validateAll(vehicles)?"VALID":"INVALID";
			System.out.println("The fleet list is "+isValid);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static boolean validateAll(Vehicles vehicles){
		
		List<Boat> boatLs=vehicles.getBoats();
		List<Bus> BusLs=vehicles.getBusses();
		List<Truck> TruckLs=vehicles.getTrucks();
		List<MotorCycle> motorcycleLs=vehicles.getMotorCycles();
		//System.out.println(boatLs.stream().allMatch(e->e.validateProps()));
		//System.out.println(BusLs.stream().allMatch(e->e.validateProps()));
		//System.out.println(TruckLs.stream().allMatch(e->e.validateProps()));
		//System.out.println(motorcycleLs.stream().allMatch(e->e.validateProps()));
		boolean b = boatLs.stream().allMatch(e->e.validateProps()) && 
					BusLs.stream().allMatch(e->e.validateProps()) &&
					TruckLs.stream().allMatch(e->e.validateProps()) &&
					motorcycleLs.stream().allMatch(e->e.validateProps());
		return b;
	}

}
