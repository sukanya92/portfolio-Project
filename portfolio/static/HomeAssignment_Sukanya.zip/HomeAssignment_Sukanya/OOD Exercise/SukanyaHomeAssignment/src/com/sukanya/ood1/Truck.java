package com.sukanya.ood1;

public class Truck extends Vehicle{

}
