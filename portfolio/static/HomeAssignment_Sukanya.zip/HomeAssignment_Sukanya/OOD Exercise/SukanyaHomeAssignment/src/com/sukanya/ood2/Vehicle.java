package com.sukanya.ood2;

import javax.xml.bind.annotation.XmlElement;

import com.sukanya.common.Validator2;


public class Vehicle {

	private Integer year;
	private String make;
	private String model;
	private String vin;

	
	@XmlElement(name="Year")
	public Integer getYear() {
		return year;
	}
	public void setYear(Integer year) {
		this.year = year;
	}
	@XmlElement(name="Make")
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	@XmlElement(name="Model")
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	
	@XmlElement(name="VinNumber")
	public String getVin() {
		return vin;
	}
	public void setVin(String vin) {
		this.vin = vin;
	}
	
	public boolean validateProps() {
		return Validator2.validateProps(year,make,model,vin);
	}

}
