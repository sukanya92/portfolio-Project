package com.sukanya.ood1;

import javax.xml.bind.annotation.XmlElement;

import com.sukanya.common.Validator;


public class Vehicle {

	private Integer year;
	private String make;
	private String model;

	@XmlElement(name="Year")
	public Integer getYear() {
		return year;
	}
	public void setYear(Integer year) {
		this.year = year;
	}
	@XmlElement(name="Make")
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	@XmlElement(name="Model")
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	
	public boolean validateProps() {
		return Validator.validateProps(year,make,model);
	}

}
