package com.sukanya.ood2;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlElement;

public class Vehicles {
	private ArrayList<Bus> busses;
	private ArrayList<Truck> trucks;
	private ArrayList<Boat> boats;
	private ArrayList<MotorCycle> motorcycles;

	@XmlElement(name = "Bus")
	public ArrayList<Bus> getBusses() {
		return busses;
	}

	public void setBusses(ArrayList<Bus> busses) {
		this.busses = busses;
	}

	@XmlElement(name = "Truck")
	public ArrayList<Truck> getTrucks() {
		return trucks;
	}

	public void setTrucks(ArrayList<Truck> trucks) {
		this.trucks = trucks;
	}

	@XmlElement(name = "Boat")
	public ArrayList<Boat> getBoats() {
		return boats;
	}

	public void setBoats(ArrayList<Boat> boats) {
		this.boats = boats;
	}

	@XmlElement(name = "Motorcycle")
	public ArrayList<MotorCycle> getMotorCycles() {
		return motorcycles;
	}

	public void setMotorCycles(ArrayList<MotorCycle> motorcycles) {
		this.motorcycles = motorcycles;
	}
	
}
