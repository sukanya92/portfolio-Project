package com.sukanya.ood2;

public class MotorCycle extends Vehicle {

}
