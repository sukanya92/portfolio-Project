package com.sukanya.ood2;

public class Bus extends Vehicle{

}
