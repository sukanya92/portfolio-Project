package com.sukanya.common;

import java.time.LocalDate;
import java.util.regex.Pattern;

public class Validator2 {
	
	public static boolean validateProps(Integer year,String make,String model, String vin) {
		//System.out.println("start-"+ year+" "+ make+" "+model+" "+ vin);
		int currYear = LocalDate.now().getYear();
		 
		 if(year==null || year<1970 || year>currYear)
			 return false;
		 
		 if(make==null || make.length()==0)
			 return false;
		 else if (make.length()>0){
			 try {
				Double.parseDouble(make);
				return false;
			} catch (NumberFormatException e) {}
		 }
		 
		 if(model==null || model.length()==0)
			 return false;
		 else if (model.length()>0){
			 try {
				Double.parseDouble(model);
				return false;
			} catch (NumberFormatException e) {}
		 }
		 
		 
		 if(vin==null || !Pattern.compile("^([0-9]{17}$)").matcher(vin).find())
			 return false;
			 
		 //System.out.println("End-"+ year+" "+ make+" "+model+" "+ vin);
		 return true;
	}
	
	
	public static boolean validateProps(Integer year,String make,String model, String vin, String nrn, String type) {
	//public static boolean validateProps(Integer year,String make,String model, String vin, String type) {	
		//System.out.println("Start-"+ year+" "+ make+" "+model+" "+ vin+" "+nrn+" "+type);
		int currYear = LocalDate.now().getYear();
		
		 if(year==null || year<1970 || year>currYear)
			 return false;
		
		 if(make==null || make.length()==0)
			 return false;
		 else if (make.length()>0){
			 try {
				Double.parseDouble(make);
				return false;
			} catch (NumberFormatException e) {}
		 }
		
		 if(model==null || model.length()==0)
			 return false;
		 else if (model.length()>0){
			 try {
				Double.parseDouble(model);
				return false;
			} catch (NumberFormatException e) {}
		 }
		
		 if(type==null || type.length()==0)
			 return false;
		 else if (type.length()>0){
			 try {
				Double.parseDouble(type);
				return false;
			} catch (NumberFormatException e) {}
		 }
		 
		 if(vin==null || !Pattern.compile("^([0-9]{17}$)").matcher(vin).find())
			 return false;
		 
		 if(nrn==null || !Pattern.compile("^[0-9]{3}-[0-9]{3}[A-Z]{8}$").matcher(nrn).find())
			 return false;
		 
		 //System.out.println("End-"+ year+" "+ make+" "+model+" "+ vin+" "+nrn+" "+type);
		 return true;
	}
}
