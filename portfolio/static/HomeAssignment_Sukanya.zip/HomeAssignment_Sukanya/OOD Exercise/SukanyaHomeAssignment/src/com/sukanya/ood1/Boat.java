package com.sukanya.ood1;

import javax.xml.bind.annotation.XmlElement;
import com.sukanya.common.Validator;

public class Boat extends Vehicle{

	private String type;

	@XmlElement(name="Type")
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public boolean validateProps() {
		return Validator.validateProps(this.getYear(),this.getMake(),this.getModel(),type);
	}
}
