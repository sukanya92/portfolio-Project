﻿using System;
using System.IO;
using System.Reflection;
using System.Xml;

namespace CalorieCalculator.API
{
    public class Calc
    {
        public static string DISTANCE_FROM_IDEAL_WEIGHT { get; set; }
        public static string IDEAL_WEIGHT { get; set; }
        public static string CALORIES { get; set; }


        public static void Calculate(string heightFeet, string heightInches, string weight, string age, The_sex sex)
        {
            //Clear old results
            DISTANCE_FROM_IDEAL_WEIGHT = "";
            IDEAL_WEIGHT = "";
            CALORIES= "";
            /* Validate User Input: */
            //Validate height (feet) is numeric value

            #region Input Validation
            double result;
            if (!double.TryParse(heightFeet, out result))
            {
                throw new Exception("Feet must be a numeric value.");
            }
            //Validate height (inches) is numeric value
            if (!double.TryParse(heightInches, out result))
            {
                throw new Exception("Inches must be a numeric value.");
            }
            //Validate weight is numeric value
            if (!double.TryParse(weight, out result))
            {
                throw new Exception("Weight must be a numeric value.");
            }
            //Validate age is numeric value
            if (!double.TryParse(age, out result))
            {
                throw new Exception("Age must be a numeric value.");
            }
            if (!(Convert.ToDouble(heightFeet) >= 5))
            {
                throw new Exception("Height has to be equal to or greater than 5 feet!");
            }
            #endregion Input Validation


            #region Calories Calculation
            /*End validation*/
            if (sex == The_sex.Male)
            {
                CALORIES = (66
                + (6.3 * Convert.ToDouble(weight))
                + (12.9 * ((Convert.ToDouble(heightFeet) * 12) + Convert.ToDouble(heightInches)))
                - (6.8 * Convert.ToDouble(age))).ToString();

                #region  Calculate ideal body weight
                //Calculate ideal body weight

                IDEAL_WEIGHT = ((50 +
                (2.3 * (((Convert.ToDouble(heightFeet) - 5) * 12)
                + Convert.ToDouble(heightInches)))) * 2.2046).ToString();
                #endregion
            }
            else
            {
                CALORIES = (655
                + (4.3 * Convert.ToDouble(weight))
                + (4.7 * ((Convert.ToDouble(heightFeet) * 12)
                + Convert.ToDouble(heightInches)))
                - (4.7 * Convert.ToDouble(age))).ToString();
                #region  Calculate ideal body weight
                //Calculate ideal body weight
                IDEAL_WEIGHT = ((45.5 +
                (2.3 * (((Convert.ToDouble(heightFeet) - 5) * 12)
                + Convert.ToDouble(heightInches)))) * 2.2046).ToString();
                #endregion
            }
            #endregion Calories Calculation


            #region Calculate and display distance from ideal weight
            //Calculate and display distance from ideal weight
            DISTANCE_FROM_IDEAL_WEIGHT = (Convert.ToDouble(weight) - Convert.ToDouble(IDEAL_WEIGHT)).ToString();
            #endregion

        }

        public enum The_sex
        {
            Male,
            Female
        }
    }
}

